/**
 * 
 */
package com.occ.utility.score.service;

import java.io.File;

/**
 * @author hemanthvuyyuru
 *
 */
public interface ScoreGenerator {
	public long calculateScore(File file);
}
