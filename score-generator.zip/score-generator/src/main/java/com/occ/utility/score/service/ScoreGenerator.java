package com.occ.utility.score.service;

import java.io.File;

public interface ScoreGenerator {
	public long calculateScore(File file);
}
